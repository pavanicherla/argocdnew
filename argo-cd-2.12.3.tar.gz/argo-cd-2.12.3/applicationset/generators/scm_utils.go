package generators

type SCMGeneratorWithCustomApiUrl interface {
	CustomApiUrl() string
}
