package testdata

import _ "embed"

//go:embed repos_gitea_go-sdk_contents_gitea.json
var ReposGiteaGoSdkContentsGiteaResponse string
