package commands

const (
	// cliName is the name of the CLI
	cliName = "argocd-server"
)
