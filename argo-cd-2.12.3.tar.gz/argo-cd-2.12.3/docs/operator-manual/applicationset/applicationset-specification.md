# ApplicationSet Specification

The following describes all the available fields of an ApplicationSet:

```yaml
{!docs/operator-manual/applicationset.yaml!}
```
