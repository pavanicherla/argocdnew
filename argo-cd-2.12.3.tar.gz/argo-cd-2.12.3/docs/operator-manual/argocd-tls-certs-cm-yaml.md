# argocd-tls-certs-cm.yaml example

An example of an argocd-tls-certs-cm.yaml file:

```yaml
{!docs/operator-manual/argocd-tls-certs-cm.yaml!}
```
