# Overview

This guide is for administrator and operator wanting to install and configure Argo CD for other developers.

!!! note
    Please make sure you've completed the [getting started guide](../getting_started.md).