# argocd-repo-creds.yaml example

An example of an argocd-repo-creds.yaml file:

```yaml
{!docs/operator-manual/argocd-repo-creds.yaml!}
```
