# argocd-secret.yaml example

An example of an argocd-secret.yaml file:

```yaml
{!docs/operator-manual/argocd-secret.yaml!}
```
