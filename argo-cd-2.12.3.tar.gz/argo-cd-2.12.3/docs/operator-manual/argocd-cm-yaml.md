# argocd-cm.yaml example

An example of an argocd-cm.yaml file:

```yaml
{!docs/operator-manual/argocd-cm.yaml!}
```
