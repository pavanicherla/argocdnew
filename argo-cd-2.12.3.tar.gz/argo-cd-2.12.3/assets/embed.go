package assets

import "embed"

// Embedded contains embedded assets
//
//go:embed *
var Embedded embed.FS
